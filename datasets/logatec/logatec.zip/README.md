Dataset downloaded from: (Log-a-tec website)[http://log-a-tec.eu/datasets-ble.html]. 

# Datasets

## Spring

Experiment run, where all positions were measured (5 x 26 points).

## Winter

Smaller experiment run, where only positions in the middle row (3) were used.

## Testbed nodes
Device numbers go from 51~71 (excluding 68) and from 81~86 (excluding 85). 


# Data Format

{
  "(<row>, <column>)": 
  {
    "<device_number>": [
      {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, ...
    ],

    "<device_number>": [
      {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, ...
    ],
  .
  .
  .
  },
  "(<row>, <column>)": 
  {
    "<device_number>": [
      {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, ...
    ],

    "<device_number>": [
      {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, {"rss": <RSS_value>, "timestamp": <timestamp_sec>}, ...
    ],
  }
}


# Aditional information

Additional information can be found on the following link: http://log-a-tec.eu

